namespace lavirint
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'a') button1.Left -= 10;
            if (e.KeyChar == 's') button1.Top += 10;
            if (e.KeyChar == 'd') button1.Left += 10;
            if (e.KeyChar == 'w') button1.Top -= 10;
            if (button1.Bounds.IntersectsWith(button2.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
            }
            if (button1.Bounds.IntersectsWith(button3.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
            }
            if (button1.Bounds.IntersectsWith(button4.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
            }
            if (button1.Bounds.IntersectsWith(button5.Bounds))
            {
                button1.Left = 12;
                button1.Top = 524;
            }
            if (button1.Bounds.IntersectsWith(button6.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
            }
            if (button1.Bounds.IntersectsWith(button7.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
            }
            if (button1.Bounds.IntersectsWith(button8.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
            }
            if (button1.Bounds.IntersectsWith(button9.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
            }
            if (button1.Bounds.IntersectsWith(button10.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
            }
            if (button1.Bounds.IntersectsWith(button11.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
            }
            if (button1.Bounds.IntersectsWith(button12.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
            }
            if (button1.Bounds.IntersectsWith(button13.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
            }
            if (button1.Bounds.IntersectsWith(button14.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
            }
            if (button1.Bounds.IntersectsWith(button15.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
            }
            if (button1.Bounds.IntersectsWith(button16.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
            }
            if (button1.Bounds.IntersectsWith(button17.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
            }



            if (button1.Bounds.IntersectsWith(button18.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
                timer2.Stop();
                timer1.Stop();
                MessageBox.Show("GAME OVER");

            }
            if (button1.Bounds.IntersectsWith(button19.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
                timer2.Stop();
                timer1.Stop();
                MessageBox.Show("GAME OVER");

            }
            if (button1.Bounds.IntersectsWith(button20.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
                timer2.Stop();
                timer1.Stop();
                MessageBox.Show("GAME OVER");

            }
            if (button1.Bounds.IntersectsWith(button21.Bounds))
            {
                button1.Left = 266;
                button1.Top = 524;
                timer2.Stop();
                timer1.Stop();
                MessageBox.Show("GAME OVER");

            }

            if (button1.Bounds.IntersectsWith(button22.Bounds))
            {
                timer2.Stop();
                timer1.Stop();
                MessageBox.Show("THE END");
                button22.Left = -500;

            }




        }

        private void button23_Click(object sender, EventArgs e)
        {
            label4.Text = "30";
            timer1.Start();
            timer2.Start();
            button1.Focus();
            button1.Left = 266;
            button1.Top = 524;
            button22.Left = 1270;
            button22.Top = 513;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            button18.Top += 5;
            if (button18.Top > 708) button18.Top = 480;

            button19.Top += 5;
            if (button19.Top > 708) button19.Top = 368;

            button20.Top -= 5;
            if (button20.Top < 402) button20.Top = 710;

            button21.Top += 5;
            if (button21.Top > 708) button21.Top = 368;



        }

        private void button19_Click(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            int vreme = Convert.ToInt16(label4.Text);
            vreme--;
            label4.Text = Convert.ToString(vreme);
            if (vreme == 0)
            {
                timer2.Stop();
                MessageBox.Show("GAME OVER");
                button1.Left = 266;
                button1.Top = 524;
                timer1.Stop();

            }

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
